package kh.java.run;

import kh.java.view.MemberMenu;

public class TestMain {

	public static void main(String[] args) {
		new MemberMenu().Menu();

	}

}
